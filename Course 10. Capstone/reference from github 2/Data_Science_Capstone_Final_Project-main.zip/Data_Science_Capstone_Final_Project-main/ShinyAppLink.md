1. My shiny App link is [here.](https://6qqr51-choonghoon-hyun.shinyapps.io/Data_Science_Capstone_Final_Shiny)

2. If the above hyper link doesn't work, please copy and paste the following URL to your browser. 
https://6qqr51-choonghoon-hyun.shinyapps.io/Data_Science_Capstone_Final_Shiny
